export default {

    newsList: state => state.newsList,

    loading: state => state.loading,

    list: state => state.list,

    ifReturnMsg: state => state.ifReturnMsg,

    userName: state => state.userName,

    vitality: state => state.vitality,

    Sharebox: state => state.Sharebox,

    logined: state => state.logined,

    showLog_off: state => state.showLog_off,

    oneDetail: state => state.oneDetail,

    collectList: state => state.collectList,

    routerChange: state => state.routerChange,

    downLoadMore: state => state.downLoadMore,

    hasIntroduce: state => state.hasIntroduce,

    introduce: state => state.introduce,
}
